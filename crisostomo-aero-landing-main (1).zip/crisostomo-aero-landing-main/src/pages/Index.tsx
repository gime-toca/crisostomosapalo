import AviationHero from "@/components/AviationHero";
import AuthorSection from "@/components/AuthorSection";
import BookSection from "@/components/BookSection";
import PricingSection from "@/components/PricingSection";
import SponsorsSection from "@/components/SponsorsSection";
import CTASection from "@/components/CTASection";

const Index = () => {
  return (
    <div className="min-h-screen">
      <AviationHero />
      <AuthorSection />
      <BookSection />
      <PricingSection />
      <SponsorsSection />
      <CTASection />
    </div>
  );
};

export default Index;
