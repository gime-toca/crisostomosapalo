import { Button } from "@/components/ui/button";
import { Plane, Phone, MapPin } from "lucide-react";
import heroImage from "@/assets/aviation-hero-bg.jpg";

const AviationHero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-aviation-futuristic opacity-80"></div>
        {/* Animated Grid Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="w-full h-full bg-gradient-to-r from-transparent via-aviation-red to-transparent animate-pulse"></div>
        </div>
      </div>
      
      {/* Floating Elements */}
      <div className="hidden sm:block absolute top-20 right-10 text-aviation-gold/40 animate-plane-fly">
        <Plane size={48} className="drop-shadow-glow" />
      </div>
      <div className="hidden sm:block absolute top-40 left-20 text-aviation-red/30 animate-float">
        <Plane size={32} className="rotate-45" />
      </div>
      
      {/* Hexagonal Background Elements */}
      <div className="hidden sm:block absolute top-1/4 right-1/4 w-20 h-20 border-2 border-aviation-gold/20 rotate-45 animate-hexagon-rotate"></div>
      <div className="hidden sm:block absolute bottom-1/3 left-1/4 w-16 h-16 border border-aviation-red/20 rotate-12 animate-float"></div>
      
      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center text-white">
        <div className="max-w-4xl mx-auto">
          {/* Pre-sale Badge */}
          <div className="inline-block bg-aviation-gold text-black px-6 py-2 rounded-full text-sm font-bold mb-6">
            PRÉ-VENDA DO LIVRO
          </div>
          
          {/* Main Title */}
          <h1 className="font-display text-[clamp(2.25rem,8vw,5.5rem)] leading-[1.15] font-black mb-6 animate-slide-in-up">
            GESTÃO<br />
            <span className="text-aviation-gold md:animate-neon-flicker drop-shadow-neon">AERONÁUTICA</span>
          </h1>
          
          {/* Author */}
          <div className="mb-8">
            <p className="text-2xl mb-2">Por</p>
            <h2 className="text-4xl font-bold italic">Crisóstomo Sapalo</h2>
          </div>
          
          {/* Publisher */}
          <div className="mb-8">
            <p className="text-lg">Publicado por <span className="font-bold">Litterae Edições</span></p>
          </div>
          
          {/* Launch Location */}
          <div className="flex items-center justify-center gap-2 mb-8 text-lg">
            <MapPin className="text-aviation-gold" />
            <span>Local do Lançamento: <strong>Hotel Diamante</strong></span>
          </div>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              variant="aviation" 
              size="lg" 
              className="text-lg px-8 py-6 shadow-futuristic hover:shadow-neon md:hover:scale-105 transition-all duration-300 animate-glow-pulse"
              onClick={() => window.open('https://wa.me/244931042605?text=Olá, gostaria de comprar o livro Gestão Aeronáutica do Crisóstomo Sapalo', '_blank')}
            >
              COMPRAR AGORA
            </Button>
            <Button 
              variant="aviation-outline" 
              size="lg" 
              className="text-lg px-8 py-6 backdrop-blur-sm border-aviation-gold/50 hover:border-aviation-gold hover:shadow-glow md:hover:scale-105 transition-all duration-300"
              onClick={() => window.open('https://wa.me/244931042605?text=Olá, gostaria de saber mais sobre o livro Gestão Aeronáutica', '_blank')}
            >
              SABER MAIS
            </Button>
          </div>
          
          {/* Contact Info */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <Phone size={16} className="text-aviation-gold" />
              <span>+244 931 042 605</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone size={16} className="text-aviation-gold" />
              <span>+244 957 264 201</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative Elements */}
      <div className="hidden sm:block absolute bottom-10 left-10 text-white/20">
        <Plane size={64} className="rotate-45" />
      </div>
    </section>
  );
};

export default AviationHero;