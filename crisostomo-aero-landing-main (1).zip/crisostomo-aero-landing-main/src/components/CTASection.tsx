import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Phone, Mail, MapPin, Clock, Star } from "lucide-react";

const CTASection = () => {
  return (
    <section className="py-20 bg-aviation-hero relative overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        
        {/* Main CTA */}
        <div className="text-center text-white mb-16">
          <h2 className="font-display text-[clamp(1.75rem,6vw,3rem)] leading-[1.2] font-black mb-6">
            Não Percas Esta<br />
            <span className="text-aviation-gold">Oportunidade Única!</span>
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Adquire já o teu exemplar de "Gestão Aeronáutica" e torna-te um especialista 
            reconhecido no sector da aviação.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              variant="aviation-gold" 
              size="lg" 
              className="text-lg px-8 py-6"
              onClick={() => window.open('https://wa.me/244931042605?text=Olá, gostaria de comprar o livro Gestão Aeronáutica com desconto', '_blank')}
            >
              <Star className="mr-2" />
              COMPRAR COM DESCONTO
            </Button>
            <Button 
              variant="aviation-outline" 
              size="lg" 
              className="text-lg px-8 py-6"
              onClick={() => window.open('https://wa.me/244931042605?text=Olá, gostaria de contactar sobre o livro Gestão Aeronáutica', '_blank')}
            >
              <Phone className="mr-2" />
              CONTACTAR AGORA
            </Button>
          </div>
        </div>

        {/* Contact Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          
          {/* Phone Contact */}
          <Card className="bg-white/10 backdrop-blur-sm border-white/20 p-6 text-white text-center hover:bg-white/20 transition-all duration-300">
            <Phone className="mx-auto text-aviation-gold mb-4" size={32} />
            <h3 className="text-lg font-bold mb-2">Telefone</h3>
            <div className="space-y-1 text-sm">
              <p>+244 931 042 605</p>
              <p>+244 957 264 201</p>
            </div>
          </Card>

          {/* Location */}
          <Card className="bg-white/10 backdrop-blur-sm border-white/20 p-6 text-white text-center hover:bg-white/20 transition-all duration-300">
            <MapPin className="mx-auto text-aviation-gold mb-4" size={32} />
            <h3 className="text-lg font-bold mb-2">Local de Lançamento</h3>
            <p className="text-sm">Hotel Diamante</p>
          </Card>

          {/* Urgency */}
          <Card className="bg-white/10 backdrop-blur-sm border-white/20 p-6 text-white text-center hover:bg-white/20 transition-all duration-300">
            <Clock className="mx-auto text-aviation-gold mb-4" size={32} />
            <h3 className="text-lg font-bold mb-2">Oferta Limitada</h3>
            <p className="text-sm">Descontos apenas até 30 de Outubro</p>
          </Card>
        </div>

        {/* Final Message */}
        <Card className="bg-aviation-gold text-black p-8 text-center max-w-4xl mx-auto">
          <h3 className="text-2xl font-bold mb-4">
            Investe no Teu Futuro Profissional
          </h3>
          <p className="text-lg mb-6">
            "Gestão Aeronáutica" não é apenas um livro, é o teu passaporte para uma carreira 
            de sucesso no sector da aviação. Junta-te aos profissionais que já escolheram a excelência.
          </p>
          
          <div className="flex items-center justify-center gap-4 mb-4">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="text-aviation-red" size={24} fill="currentColor" />
            ))}
          </div>
          <p className="font-bold">Avaliado com 5 estrelas por especialistas do sector</p>
        </Card>
      </div>

      {/* Background Pattern */}
      <div className="hidden sm:block absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 text-white/20 transform rotate-12">
          <svg width="100" height="100" viewBox="0 0 100 100" fill="currentColor">
            <path d="M50 5 L90 85 L10 85 Z" />
          </svg>
        </div>
        <div className="absolute bottom-20 right-20 text-white/20 transform -rotate-12">
          <svg width="100" height="100" viewBox="0 0 100 100" fill="currentColor">
            <path d="M50 5 L90 85 L10 85 Z" />
          </svg>
        </div>
      </div>
    </section>
  );
};

export default CTASection;