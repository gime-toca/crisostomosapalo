import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, TrendingDown, Calendar, Phone } from "lucide-react";

const PricingSection = () => {
  const pricingPlans = [
    {
      period: "Até 30 de Setembro",
      price: "10.000 KZ",
      originalPrice: "15.000 KZ",
      discount: "33% OFF",
      badge: "MELHOR OFERTA",
      color: "bg-green-500"
    },
    {
      period: "Até 30 de Outubro", 
      price: "13.000 KZ",
      originalPrice: "15.000 KZ",
      discount: "13% OFF",
      badge: "OFERTA LIMITADA",
      color: "bg-aviation-gold"
    },
    {
      period: "Preço de Lançamento",
      price: "15.000 KZ",
      originalPrice: null,
      discount: null,
      badge: "PREÇO NORMAL",
      color: "bg-aviation-red"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge className="bg-aviation-red text-white mb-4 text-sm px-4 py-2">
            APROVEITE AS PROMOÇÕES
          </Badge>
          <h2 className="font-display text-[clamp(1.75rem,6vw,3rem)] leading-[1.2] font-black text-aviation-red mb-6">
            Ofertas Especiais de<br />
            <span className="text-aviation-gold">Pré-Venda</span>
          </h2>
          <p className="text-base sm:text-xl text-gray-600 max-w-2xl mx-auto">
            Garante já o teu exemplar com desconto especial. Quanto mais cedo comprares, mais poupas!
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {pricingPlans.map((plan, index) => (
            <Card 
              key={index} 
              className={`relative p-8 text-center border-2 transition-all duration-300 md:hover:scale-105 md:hover:shadow-aviation ${
                index === 0 ? 'border-green-500 bg-green-50' : 
                index === 1 ? 'border-aviation-gold bg-yellow-50' : 
                'border-aviation-red bg-red-50'
              }`}
            >
              {/* Badge */}
              <Badge className={`${plan.color} text-white mb-4 text-xs px-3 py-1`}>
                {plan.badge}
              </Badge>
              
              {/* Period */}
              <h3 className="text-lg font-bold text-gray-800 mb-4">
                {plan.period}
              </h3>
              
              {/* Price */}
              <div className="mb-6">
                <div className="text-4xl font-black text-aviation-red mb-2">
                  {plan.price}
                </div>
                {plan.originalPrice && (
                  <div className="text-lg text-gray-500 line-through">
                    {plan.originalPrice}
                  </div>
                )}
                {plan.discount && (
                  <Badge className="bg-green-500 text-white text-xs mt-2">
                    {plan.discount}
                  </Badge>
                )}
              </div>
              
              {/* CTA */}
              <Button 
                variant={index === 0 ? "default" : "aviation"} 
                size="lg" 
                className="w-full"
                onClick={() => window.open(`https://wa.me/244931042605?text=Olá, gostaria de comprar o livro Gestão Aeronáutica por ${plan.price}`, '_blank')}
              >
                COMPRAR AGORA
              </Button>
              
              {/* Countdown for first option */}
              {index === 0 && (
                <div className="mt-4 text-sm text-green-600 font-semibold">
                  <Clock size={16} className="inline mr-1" />
                  Oferta por tempo limitado!
                </div>
              )}
            </Card>
          ))}
        </div>

        {/* Launch Date Info */}
        <Card className="bg-aviation-gradient text-white p-8 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Calendar className="text-aviation-gold" />
            <h3 className="text-2xl font-bold">Data de Venda Oficial</h3>
          </div>
          <p className="text-3xl font-black text-aviation-gold mb-4">
            01/11/2025
          </p>
          <p className="text-lg mb-6">
            Após esta data, o livro estará disponível ao preço normal de 15.000 KZ
          </p>
          
          {/* Contact Info */}
          <div className="border-t border-white/20 pt-6">
            <h4 className="text-lg font-bold mb-4">Para mais informações, contacta:</h4>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-lg">
              <div className="flex items-center gap-2">
                <Phone className="text-aviation-gold" />
                <span>+244 931 042 605</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="text-aviation-gold" />
                <span>+244 957 264 201</span>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
};

export default PricingSection;