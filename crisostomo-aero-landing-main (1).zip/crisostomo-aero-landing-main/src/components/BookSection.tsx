import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Star, CheckCircle, Plane } from "lucide-react";



const BookSection = () => {
  return (
    <section className="py-20 bg-aviation-gradient">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Book Info */}
          <div className="text-white space-y-6">
            <div>
              <Badge className="bg-aviation-gold text-black font-bold mb-4">
                BESTSELLER EM GESTÃO AERONÁUTICA
              </Badge>
              <h2 className="font-display text-[clamp(1.75rem,6vw,3rem)] leading-[1.2] font-black mb-4">
                O Livro Definitivo sobre<br />
                <span className="text-aviation-gold">Gestão Aeronáutica</span>
              </h2>
            </div>
            
            <div className="space-y-4 text-lg leading-relaxed">
              <p>
                Este livro aborda de forma abrangente os aspectos fundamentais da gestão 
                no sector aeronáutico, desde operações aeroportuárias até gestão de companhias aéreas.
              </p>
              <p>
                Uma obra essencial para profissionais, estudantes e gestores que desejam 
                compreender e dominar os princípios da aviação comercial moderna.
              </p>
            </div>
            
            {/* Book Details */}
            <Card className="bg-white/10 backdrop-blur-sm border-white/20 p-5 sm:p-6">
              <h3 className="text-xl font-bold mb-4 text-aviation-gold">Detalhes da Obra</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-aviation-gold font-semibold">ISBN:</span>
                  <p className="break-all">0060.0114.0100.0305.7836.0</p>
                </div>
                <div>
                  <span className="text-aviation-gold font-semibold">Editora:</span>
                  <p>Litterae Edições</p>
                </div>
                <div>
                  <span className="text-aviation-gold font-semibold">Idioma:</span>
                  <p>Português</p>
                </div>
                <div>
                  <span className="text-aviation-gold font-semibold">Categoria:</span>
                  <p>Gestão & Aviação</p>
                </div>
              </div>
            </Card>
            
            {/* Key Topics */}
            <div>
              <h3 className="text-xl font-bold mb-4 text-aviation-gold">Principais Temas Abordados</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  "Noções Gerais de Aeronáutica",
                  "Aviação Civil",
                  "Gestão Aeronáutica",
                  "Serviços de Tráfego Aéreo"
                ].map((topic, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <CheckCircle size={16} className="text-aviation-gold" />
                    <span className="text-sm">{topic}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
        {/* Book Stack Image */}
        <div className="relative">
          {/* Glowing Background Effect */}
          <div className="absolute inset-0 bg-aviation-neon opacity-20 blur-3xl animate-glow-pulse"></div>
          
          <div className="relative z-10 max-w-md mx-auto md:hover:scale-110 transition-all duration-500 md:animate-float">
            <img 
              src="/lovable-uploads/2c05d7e3-8499-4602-abfa-1bbf083a006b.png"
              alt="Stack de Livros Gestão Aeronáutica"
              className="w-full rounded-lg shadow-futuristic border border-aviation-red/30"
            />
            
            {/* Star Rating */}
            <div className="absolute -top-4 -right-4 bg-aviation-gold text-black p-3 rounded-full shadow-neon animate-glow-pulse">
              <div className="flex items-center gap-1">
                <Star size={16} fill="currentColor" className="animate-spin-slow" />
                <span className="text-sm font-bold">5.0</span>
              </div>
            </div>
            
            {/* Holographic Border Effect */}
            <div className="absolute inset-0 rounded-lg border-2 border-aviation-gold/50 animate-neon-flicker"></div>
          </div>
            
          {/* Decorative Elements */}
          <div className="hidden sm:block absolute -top-8 -left-8 text-white/20 animate-float">
            <Plane size={64} className="rotate-12 animate-glow-pulse" />
          </div>
          <div className="hidden sm:block absolute -bottom-8 -right-8 text-white/20 animate-float delay-300">
            <BookOpen size={64} className="-rotate-12 animate-glow-pulse" />
          </div>
          
          {/* Additional Futuristic Elements */}
          <div className="hidden sm:block absolute top-1/4 -left-6 w-12 h-12 border-2 border-aviation-gold/30 rotate-45 animate-hexagon-rotate"></div>
          <div className="hidden sm:block absolute bottom-1/3 -right-6 w-8 h-8 bg-aviation-red/20 rounded-full animate-glow-pulse"></div>
          
          {/* Enhanced Glow Effect */}
          <div className="absolute inset-0 bg-aviation-gold/20 rounded-lg blur-3xl transform scale-110 animate-glow-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BookSection;