import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Plane, BookOpen, Award } from "lucide-react";


const AuthorSection = () => {
  return (
    <section className="py-20 bg-gradient-to-b from-white to-muted">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Author Photo */}
          <div className="relative">
            {/* Glowing Background Effect */}
            <div className="absolute inset-0 bg-aviation-neon opacity-20 blur-3xl animate-glow-pulse"></div>
            
            <div className="relative z-10 max-w-sm mx-auto md:hover:scale-105 transition-all duration-500 md:animate-float">
              <img 
                src="/lovable-uploads/66af5cb5-78ba-4726-9740-8d615516d026.png"
                alt="Crisóstomo Sapalo - Autor"
                className="w-full rounded-lg shadow-futuristic border border-aviation-red/30"
              />
              
              {/* Professional Badge */}
              <div className="absolute -bottom-4 -right-4 bg-aviation-red text-white p-3 rounded-full shadow-neon animate-glow-pulse">
                <Award size={20} className="animate-spin-slow" />
              </div>
              
              {/* Holographic Border Effect */}
              <div className="absolute inset-0 rounded-lg border-2 border-aviation-gold/50 md:animate-neon-flicker"></div>
            </div>
            
            {/* Additional Futuristic Elements */}
            <div className="hidden sm:block absolute top-1/2 -left-4 w-8 h-8 border-2 border-aviation-gold/30 rotate-45 animate-hexagon-rotate"></div>
            <div className="hidden sm:block absolute top-1/4 -right-4 w-6 h-6 bg-aviation-red/20 rounded-full animate-glow-pulse"></div>
            <div className="hidden sm:block absolute bottom-1/4 left-1/2 w-12 h-12 border border-aviation-red/20 rounded-full animate-float delay-700"></div>
          </div>
          
          {/* Author Info */}
          <div className="space-y-6">
            <div>
              <h2 className="font-display text-[clamp(1.75rem,6vw,3rem)] leading-[1.2] font-black text-aviation-red mb-4">
                Sobre o Autor
              </h2>
              <h3 className="text-[clamp(1.25rem,4.5vw,1.875rem)] font-bold italic text-gray-800 mb-6">
                Crisóstomo Sapalo
              </h3>
            </div>
            
            <div className="space-y-4 text-lg text-gray-700 leading-relaxed">
              <div className="backdrop-blur-sm bg-white/80 p-4 rounded-lg border border-aviation-red/20 animate-slide-in-up">
                <p>
                  <strong className="text-aviation-red">Escritor e Técnico de Informação e Telecomunicações Aeronáuticas</strong> com 
                  experiência em aviação civil há <strong className="text-aviation-gold">14 anos</strong> pela 
                  Empresa Nacional de Navegação Aérea (ENNA-EP).
                </p>
              </div>
              <div className="backdrop-blur-sm bg-white/80 p-4 rounded-lg border border-aviation-red/20 animate-slide-in-up delay-200">
                <p>
                  Especialista em <strong className="text-aviation-red">Gestão de Informação Aeronáutica 
                  (Management Information Aeronautical-AIM)</strong> pela ATNS - Aviation Training Academy - ATA South Africa.
                </p>
              </div>
              <div className="backdrop-blur-sm bg-white/80 p-4 rounded-lg border border-aviation-red/20 animate-slide-in-up delay-400">
                <p>
                  Possui formações específicas como <strong className="text-aviation-gold">AIM General, Quality e EAIP, 
                  Digital NOTAN, AMDB e AIXM 5.1</strong>, ministradas pela GROUPEAD Escola de Formação 
                  Aeronáutica Espanhola sediada em Madrid, Espanha.
                </p>
              </div>
            </div>
            
            {/* Author Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8">
              <Card className="p-4 border-aviation-red/20 hover:shadow-futuristic transition-all duration-300 md:hover:scale-105 backdrop-blur-sm bg-white/90 md:animate-float">
                <div className="flex items-center gap-3">
                  <Award className="text-aviation-red animate-glow-pulse" size={24} />
                  <div>
                    <h4 className="font-bold text-aviation-red">14 Anos ENNA-EP</h4>
                    <p className="text-sm text-gray-600">Informação Aeronáutica</p>
                  </div>
                </div>
              </Card>
              
              <Card className="p-4 border-aviation-red/20 hover:shadow-futuristic transition-all duration-300 md:hover:scale-105 backdrop-blur-sm bg-white/90 md:animate-float delay-300">
                <div className="flex items-center gap-3">
                  <BookOpen className="text-aviation-red animate-glow-pulse" size={24} />
                  <div>
                    <h4 className="font-bold text-aviation-red">Certificado ATA</h4>
                    <p className="text-sm text-gray-600">South Africa</p>
                  </div>
                </div>
              </Card>
            </div>
            
            <Button 
              variant="aviation" 
              size="lg" 
              className="mt-8 shadow-futuristic hover:shadow-neon md:hover:scale-105 transition-all duration-300 animate-glow-pulse"
              onClick={() => window.open('https://wa.me/244931042605?text=Olá, gostaria de conhecer mais sobre o autor Crisóstomo Sapalo', '_blank')}
            >
              Conhece Mais Sobre o Autor
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AuthorSection;