import { Card } from "@/components/ui/card";
import { Plane, Building, Users, Award } from "lucide-react";

const SponsorsSection = () => {
  const sponsors = [
    {
      type: "PATROCINADOR",
      name: "ENNA",
      icon: Building,
      description: "Parceiro principal"
    }
  ];

  const supporters = [
    {
      name: "TAAG",
      logo: "/lovable-uploads/49fc9f68-a064-477b-ae4a-013a3e8519a7.png",
      description: "TAAG - Angola Airlines"
    },
    {
      name: "ENNA",
      logo: "/lovable-uploads/eabdf7c2-3884-4458-a162-7af9cb529d0a.png",
      description: "Empresa Nacional de Navegação Aérea"
    },
    {
      name: "AVIAÇÃO DE ANGOLA",
      logo: "/lovable-uploads/90a9a010-5d57-453e-9bb2-7967347dd947.png",
      description: "Portal de Notícia Exclusivo para Aviação Civil"
    },
    {
      name: "ANAC",
      logo: "/lovable-uploads/8e562c95-8c55-44ad-8921-a6b66bb8095e.png",
      description: "Autoridade Nacional da Aviação Civil"
    },
    {
      name: "AEAC",
      logo: "/lovable-uploads/bf8c3e8e-29b8-4892-b508-63ec33119eb9.png",
      description: "Associação de Estudantes da Aviação Civil"
    }
  ];

  return (
    <section className="py-16 bg-muted">
      <div className="container mx-auto px-4">
        
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-aviation-red mb-4">
            Apoiado por Organizações de Renome
          </h2>
          <p className="text-lg text-gray-600">
            Este projecto conta com o apoio de instituições líderes no sector aeronáutico
          </p>
        </div>

        {/* Main Sponsor */}
        <div className="mb-12">
          <h3 className="text-xl font-bold text-center text-aviation-red mb-6 animate-neon-flicker">PATROCINADOR PRINCIPAL</h3>
          <Card className="max-w-md mx-auto p-8 text-center border-aviation-red/20 hover:shadow-futuristic transition-all duration-300 md:hover:scale-105 backdrop-blur-sm bg-aviation-futuristic animate-glow-pulse">
            <Building className="mx-auto text-aviation-red mb-4 animate-float" size={48} />
            <h4 className="text-2xl font-bold text-aviation-red mb-2">ENNA</h4>
            <p className="text-gray-300">Empresa Nacional de Navegação Aérea</p>
            <div className="mt-4 w-full h-1 bg-aviation-neon rounded"></div>
          </Card>
        </div>

        {/* Supporters */}
        <div>
          <h3 className="text-xl font-bold text-center text-aviation-red mb-6">APOIO INSTITUCIONAL</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {supporters.map((supporter, index) => (
              <Card 
                key={index}
                className="p-4 text-center border-aviation-red/20 hover:shadow-futuristic transition-all duration-300 md:hover:scale-105 backdrop-blur-sm bg-white/5 animate-slide-in-up"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="mb-3 h-16 flex items-center justify-center">
                  <img 
                    src={supporter.logo} 
                    alt={supporter.name}
                    className="max-h-full max-w-full object-contain"
                  />
                </div>
                <h4 className="text-sm font-bold text-aviation-red mb-1">
                  {supporter.name}
                </h4>
                <p className="text-xs text-gray-600">{supporter.description}</p>
                <div className="mt-3 w-full h-0.5 bg-aviation-gradient rounded"></div>
              </Card>
            ))}
          </div>
        </div>

        {/* Additional Recognition */}
        <Card className="mt-12 bg-aviation-gradient text-white p-8 text-center">
          <Users className="mx-auto text-aviation-gold mb-4" size={48} />
          <h3 className="text-2xl font-bold mb-4">Reconhecimento Profissional</h3>
          <p className="text-lg">
            Este livro é reconhecido por profissionais e instituições do sector aeronáutico 
            como uma obra de referência em gestão aeronáutica em Angola e África.
          </p>
        </Card>
      </div>
    </section>
  );
};

export default SponsorsSection;